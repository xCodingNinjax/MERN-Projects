const ProductController = require("../controllers/product.controller");

odule.exports = (app)=>{
    app.post("/api/products", ProductController.createProduct);
}