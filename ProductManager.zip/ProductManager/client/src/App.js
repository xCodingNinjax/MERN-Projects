import CreateProduct from "./components/CreateProduct";
import './App.css';

function App() {
  return (
    <div className="App">
      <CreateProduct path="/" />
    </div>
  );
}

export default App;
