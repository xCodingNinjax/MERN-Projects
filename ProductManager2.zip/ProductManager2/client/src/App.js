import Main from "./view/Main";
import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import OneProduct from "./components/OneProduct";

function App() {
  return (
    <BrowserRouter>
    <div className="App">
      
      <Routes>
      <Route path="/" element={<Main/>}/>
      <Route path="/product/:id" element={<OneProduct/>}/> 
      </Routes>
    </div>
    </BrowserRouter>
  );
}

export default App;

