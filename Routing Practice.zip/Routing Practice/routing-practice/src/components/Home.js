import React from "react"




const Home = (props) => {
    return(
      <div style={{textAlign: 'center'}}>
        <h1>Welcome</h1>
        
  
      </div>
    )
  }




  export default Home;